<?php
/*
Plugin Name: AssetPayments Woocommerce Payment Gateway V2
Description: Plugin for paying for products through the AssetPayments service. Works in conjunction with the Woocommerce plugin
Version: 4.1.0
Requires at least: 5.7.2
Requires PHP: 7.x
Author: AssetPayments
License: GPL v2 or later
Text Domain: wc-assetpayments-v2
*/

if (!defined('ABSPATH')) exit;

// Main plugin file constant used by Blocks integration for stable asset URLs.
if ( ! defined( 'WC_ASSETPAYMENTS_V2_PLUGIN_FILE' ) ) {
    define( 'WC_ASSETPAYMENTS_V2_PLUGIN_FILE', __FILE__ );
}

add_action('plugins_loaded', 'woocommerce_assetpayments_v2_init', 11);

function woocommerce_assetpayments_v2_init() {
    if (!class_exists('WC_Payment_Gateway')) return;

    include_once('includes/WC_Gateway_kmnd_Assetpayments_V2.php');
    include_once('includes/class-wc-assetpayments-v2-blocks.php');

    add_filter('woocommerce_payment_gateways', 'woocommerce_add_assetpayments_v2_gateway');
    function woocommerce_add_assetpayments_v2_gateway($methods) {
        $methods[] = 'WC_Gateway_kmnd_Assetpayments_V2';
        return $methods;
    }
}

add_filter('woocommerce_locate_template', 'custom_woocommerce_locate_template_v2', 10, 3);

function custom_woocommerce_locate_template_v2($template, $template_name, $template_path) {
    global $woocommerce;

    $_template = $template;

    if (!$template_path) $template_path = $woocommerce->template_url;

    $plugin_path = untrailingslashit(plugin_dir_path(__FILE__)) . '/templates/';

    $template = locate_template(
        array(
            $template_path . $template_name,
            $template_name
        )
    );

    if (!$template && file_exists($plugin_path . $template_name))
        $template = $plugin_path . $template_name;

    if (!$template)
        $template = $_template;

    return $template;
}

require_once plugin_dir_path(__FILE__) . 'includes/wc-assetpayments-v2-callback.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-wc-assetpayments-v2-page-redirect.php';

// Add Settings link on Plugins page
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'assetpayments_v2_settings_link');

function assetpayments_v2_settings_link($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=assetpayments-v2') . '">' . __('Settings', 'wc-assetpayments-v2') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
